let farmerFrames = ["🧑‍🌾", "🧑‍🌾"]; // Adicionando um frame com uma muda
let currentFrame = 0;
let frameRateFarmer = 10; // Quão rápido a animação do fazendeiro muda

let treeEmojis = ["🌳", "🌲", "🌴"];
let trees = [];
let farmerX;
let farmerY;
let speed = 2;
let temperature = 30;
let temperatureDecreaseRate = 0.005; // Reduzindo um pouco a taxa

let clouds = [];
let cloudSpeed = 0.5;
let sunX;
let sunY;
let sunRadius = 30;

function setup() {
  createCanvas(600, 400);
  farmerX = 50;
  farmerY = height - 50;
  sunX = width - 50;
  sunY = 50;

  // Inicializar algumas nuvens
  for (let i = 0; i < 3; i++) {
    clouds.push({
      x: random(width),
      y: random(height / 2),
      size: random(50, 100),
    });
  }
}

function draw() {
  background(135, 206, 235); // Céu azul claro

  // Desenhar o sol
  fill(255, 255, 0);
  ellipse(sunX, sunY, sunRadius * 2, sunRadius * 2);

  // Mover e desenhar as nuvens
  fill(255);
  for (let cloud of clouds) {
    ellipse(cloud.x, cloud.y, cloud.size, cloud.size * 0.6);
    cloud.x += cloudSpeed;
    if (cloud.x > width + cloud.size / 2) {
      cloud.x = -cloud.size / 2;
      cloud.y = random(height / 2);
      cloud.size = random(50, 100);
    }
  }

  // Desenhar o chão
  fill(101, 67, 33); // Marrom
  rect(0, height - 30, width, 30);

  // Desenhar árvores
  for (let tree of trees) {
    textSize(32);
    text(tree.emoji, tree.x, height - 55);
  }

  // Animação do fazendeiro
  textSize(48);
  text(farmerFrames[currentFrame], farmerX, farmerY);
  if (frameCount % frameRateFarmer == 0) {
    currentFrame = (currentFrame + 1) % farmerFrames.length;
  }

  // Mostrar informações
  textSize(16);
  fill(0);
  text(`Temperatura: ${temperature.toFixed(2)} °C`, 20, 20);
  text(`Árvores plantadas: ${trees.length}`, 20, 40);

  // Movimentação do fazendeiro
  if (keyIsDown(LEFT_ARROW)) {
    farmerX -= speed;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    farmerX += speed;
  }
  farmerX = constrain(farmerX, 0, width - 40);

  // Diminuir a temperatura
  temperature -= trees.length * temperatureDecreaseRate;
  temperature = max(temperature, 15);
}

function mouseClicked() {
  // Plantar uma árvore aleatória
  let randomTreeEmoji = random(treeEmojis);
  trees.push({ x: mouseX, emoji: randomTreeEmoji });
}